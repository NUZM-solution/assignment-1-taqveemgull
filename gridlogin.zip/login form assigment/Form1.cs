namespace login_form_assigment
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "" && textBox2.Text == "")
            {
                MessageBox.Show("Please enter username and password");
            }
            else
            {
                if (textBox1.Text == "Taqveem Gull" && textBox2.Text == "22011556-001")
                {
                    MessageBox.Show("you are successfully Login");
                }

            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            // Assuming you have text boxes named 'textBoxUsername' and 'textBoxPassword'
            textBox1.Clear();
            textBox2.Clear();

            // If you have any state variables, reset them here
            // e.g., loginAttempts = 0;
        }



        private void button3_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
