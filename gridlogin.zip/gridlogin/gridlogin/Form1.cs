﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace gridlogin
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnInsert_Click(object sender, EventArgs e)
        {
            //Get data from input fields
            string CourseCode = textBox1.Text;
            string CourseTitle = textBox2.Text;
            string ObtainedMarks = textBox3.Text;
            string Grade = textBox4.Text;
            //Add a row to datagridview
            DataGridViewRow newRow = new DataGridViewRow();
            //create cells for each column in datagridview
            DataGridViewCell cell1 = new DataGridViewTextBoxCell();
            DataGridViewCell cell2 = new DataGridViewTextBoxCell();
            DataGridViewCell cell3 = new DataGridViewTextBoxCell();
            DataGridViewCell cell4 = new DataGridViewTextBoxCell();
            DataGridViewCell cell5 = new DataGridViewTextBoxCell();
            //Set the cell values to the data from input fields
            cell1.Value = CourseCode;
            cell2.Value = CourseTitle;
            cell3.Value = ObtainedMarks;
            cell4.Value = Grade;
            //Add cells to the new row
            newRow.Cells.Add(cell1);
            newRow.Cells.Add(cell2);
            newRow.Cells.Add(cell3);
            newRow.Cells.Add(cell4);
            dataGridView1.Rows.Add(newRow);
        }
        private void btnNew_Click(object sender, EventArgs e)
        {
            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
            textBox4.Text = "";
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                foreach (DataGridViewRow row in dataGridView1.SelectedRows)
                {
                    dataGridView1.Rows.Remove(row);
                }
            }
            else
            {
                MessageBox.Show("Please select a row ");
            }
        }
    }
}
      
